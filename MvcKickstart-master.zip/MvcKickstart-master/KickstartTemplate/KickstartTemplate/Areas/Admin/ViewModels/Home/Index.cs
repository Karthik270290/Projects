﻿namespace KickstartTemplate.Areas.Admin.ViewModels.Home
{
	public class Index
	{
	}
}