﻿namespace Omu.ProDinner.WebUI.ViewModels.Input
{
    public class Input
    {
        public int Id { get; set; }
    }
}