﻿namespace KickstartTemplate.ViewModels.Mail
{
	public class Welcome : EmailBase
	{
		public string Username { get; set; }
	}
}