﻿namespace MvcKickstart.Infrastructure
{
	public enum NotificationType
	{
		Info,
		Success,
		Warning,
		Error
	}
}