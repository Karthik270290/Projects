namespace Omu.ProDinner.WebUI
{
    public static class Globals
    {
        public static string PicturesPath { get; set; }
    }
}