﻿namespace Omu.ProDinner.WebUI.ViewModels.Input
{
    public class BatchDeleteConfirmInput
    {
        public int[] Ids { get; set; }
    }
}