﻿namespace MvcKickstart.Analytics.Infrastructure
{
	public static class CacheKeys
	{
		public const string SiteSettings = "SiteSettings";
	}
}
