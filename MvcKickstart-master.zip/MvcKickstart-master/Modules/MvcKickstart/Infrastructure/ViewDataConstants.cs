﻿namespace MvcKickstart.Infrastructure
{
	public abstract class ViewDataConstants
	{
		public const string Notification = "Notification";
		public const string ProfileActionStopwatch = "ProfileActionStopwatch";
	}
}