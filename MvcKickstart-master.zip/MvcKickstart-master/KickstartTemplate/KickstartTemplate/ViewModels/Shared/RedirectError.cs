﻿namespace KickstartTemplate.ViewModels.Shared
{
	public class RedirectError : MvcKickstart.ViewModels.Error
	{
		public string RedirectUrl { get; set; }
	}
}