﻿namespace Omu.ProDinner.WebUI.ViewModels.Input
{
    public class CropInput
    {
        public int ImageHeight { get; set; }
        public int ImageWidth { get; set; }
        public int Id { get; set; }
        public string FileName { get; set; }
    }
}