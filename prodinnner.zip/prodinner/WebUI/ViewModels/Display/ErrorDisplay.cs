﻿namespace Omu.ProDinner.WebUI.ViewModels.Display
{
    public class ErrorDisplay
    {
        public string Message { get; set; }
    }
}