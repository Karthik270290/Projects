﻿namespace KickstartTemplate.Infrastructure
{
	public enum Navigation
	{
		None,
		Home,
	}
}