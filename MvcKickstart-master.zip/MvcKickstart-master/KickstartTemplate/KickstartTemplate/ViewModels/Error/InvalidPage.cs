﻿namespace KickstartTemplate.ViewModels.Error
{
	public class InvalidPage
	{
	}
}