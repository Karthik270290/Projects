﻿using KickstartTemplate.Infrastructure;

namespace KickstartTemplate.ViewModels.Shared
{
	public class Menu
	{
		public Navigation Nav { get; set; }
	}
}