﻿namespace MvcKickstart.Analytics.ViewModels.Widgets
{
	public class Authorize
	{
		public string Url { get; set; }
	}
}