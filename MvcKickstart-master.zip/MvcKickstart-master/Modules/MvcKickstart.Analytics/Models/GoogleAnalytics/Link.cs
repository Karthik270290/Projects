﻿namespace MvcKickstart.Analytics.Models.GoogleAnalytics
{
	public class Link
	{
		public string Type { get; set; }
		public string Href { get; set; }
	}
}