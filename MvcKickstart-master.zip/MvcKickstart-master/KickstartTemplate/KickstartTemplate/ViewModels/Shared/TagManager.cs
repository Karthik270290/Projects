﻿namespace KickstartTemplate.ViewModels.Shared
{
	public class TagManager
	{
		/// <summary>
		/// Tag manager id
		/// </summary>
		public string Id { get; set; }
	}
}