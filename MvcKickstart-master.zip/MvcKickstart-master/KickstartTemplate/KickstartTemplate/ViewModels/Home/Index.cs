﻿namespace KickstartTemplate.ViewModels.Home
{
	public class Index
	{
	}
}