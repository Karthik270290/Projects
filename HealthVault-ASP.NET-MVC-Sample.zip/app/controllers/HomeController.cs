﻿// ********************************************************
//
// Copyright (c) Microsoft. All rights reserved.
// This code is licensed under the Microsoft Public License.
// THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
// IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
// PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
//
// ********************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.Health.Web.Mvc;
using Microsoft.Health.ItemTypes;

namespace MvcHelloWorld.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            if (!User.Identity.IsAuthenticated)
            {
                ViewBag.Message = "Welcome to HealthVault with ASP.NET MVC!";
            }
            else
            {
                ViewBag.Message = "Welcome, " + User.Identity.Name + ", to HealthVault with ASP.NET MVC!";
            }

            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        [RequireSignIn]
        public ActionResult Basic()
        {
            var record = User.PersonInfo().SelectedRecord;
            var basics = record.GetItemsByType(BasicV2.TypeId);
            if (basics.Count > 0)
            {
                return View(basics[0]);
            }

            return View();
        }
    }
}
